package com.tanhoang.emvreadernfckotlin.lib.enums

/**
 * @author AliMertOzdemir
 * @class BeepType
 * @created 20.04.2020
 */
enum class BeepType {
    SUCCESS, FAIL
}
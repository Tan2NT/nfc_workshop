package com.tanhoang.emvreadernfckotlin.lib.model

/**
 * @author AliMertOzdemir
 * @class TlvObject
 * @created 17.04.2020
 */
class TlvObject(val tlvTag: ByteArray, val tlvTagLength: Int)